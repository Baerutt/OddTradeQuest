﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace TheOddTradingGame
{
    public class Player
    {
        public string name;
        public List<Item> inventory = new List<Item>();

        public Player()
        {

        }
        public Player(string thisName, List<Item> stuff)
        {
            name = thisName;
            inventory = stuff;
        }
    }
    
}
