﻿using System;
using System.Collections.Generic;
using System.DirectoryServices.ActiveDirectory;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace TheOddTradingGame
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private MediaPlayer mediaPlayer = new MediaPlayer();
        private MediaPlayer effectPlayer = new MediaPlayer();
        public Player protag = new Player();
        string pName = "";
        public string fullDialogue = "";
        NPC ThisGuy = new NPC("This Guy", "Oh no! My poor Smurf Chick... where have you run to...\nI'll give you something in return if you can\nfind him and bring him back!", new Item("Dope Shroom", 3), new Uri("Resources/ThisGuy.png", UriKind.Relative));
        NPC CreepyGirl = new NPC("Creepy Girl", "Man, I am starving. Oh, the old guy? \nHe's Dead. I'll give you something in return if you can\ngive me something to eat.", new Item("Jiggy Saw", 5), new Uri("Resources/CreepyGirl.png", UriKind.Relative));
        NPC craftsman = new NPC("Craftsman", "I would love to start working, but I seem to missing my saw.\nDo you have it?", new Item("Broken Sword", 6), new Uri("Resources/Craftsman.png", UriKind.Relative));
        NPC Biggoron1 = new NPC("Biggoron", "Im the world's best swordsmith. I'd love to fix something, but I need something to fix first", new Item("Prescription", 7), new Uri("Resources / Biggoron.png", UriKind.Relative));
        NPC Biggoron2 = new NPC("Biggoron", "I need my eyedrops to fix anything.\nSo, did you bring my eyedrops back yet?", new Item("Stabby Stab", 9), new Uri("Resources/Biggoron.png", UriKind.Relative));
        NPC Granny1 = new NPC("Granny", "If only I had something to make a potion with... Then I'd be happy\nIf you give me that item, I might be able to cook something for you", new Item("Odd Potluck", 4), new Uri("Resources/Granny.png", UriKind.Relative));
        NPC Granny2 = new NPC("Granny", "I have a patient that's coming soon\nI'll just need his prescription and I'll be all set to hand this off", new Item("World's Biggest Eyedrops", 8), new Uri("Resources/Granny.png", UriKind.Relative));
        NPC CuccooLady = new NPC("Cuccoo Lady", "Oh no! I've lost my White Chick... \nI'll give you something in return if you can\nfind him and bring him back!", new Item("Smurf Chick", 2), new Uri("Resources/CuccoLady.png", UriKind.Relative));
        Item egg = new Item("White Egg", 0);
        Location menu = new Location("Menu", 1);
        Location forest1 = new Location("Forest", 1);
        Location forest2 = new Location("Forest", 2);
        Location village1 = new Location("Village", 1);
        Location pharmacy1 = new Location("Pharmacy", 1);
        Location mountain1 = new Location("Mountain", 1);
        Location desert1 = new Location("Desert", 1);
        Location IAmAt;
        public MainWindow()
        {
            InitializeComponent();
            if (protag.inventory.Count == 0)
            {
                protag.inventory.Add(egg);
                ContentFrame.Navigate(new TrackingScreen());
                Uri soundUri = new Uri("resources/KakarikoVillageOoTN64Edit.mp3", UriKind.Relative);
                mediaPlayer.Open(soundUri);
                mediaPlayer.Play();
                mediaPlayer.MediaEnded += Media_Ended;
                Thread.Sleep(1);
                IAmAt = menu;
                
            }

        }

        private void Media_Ended(object sender, EventArgs e)
        {
            mediaPlayer.Position = TimeSpan.Zero;
            mediaPlayer.Play();
        }
        private void LocationBox_Load(object sender, EventArgs e)
        {
            List<Location> places = new List<Location>();
            places.Add(menu);
            places.Add(forest1);
            places.Add(village1);
            places.Add(pharmacy1);
            places.Add(mountain1);
            places.Add(desert1);


        }

        private void LocationBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (protag.inventory.Count == 0 || protag.inventory[0].ID >= 4)
            {

            }
        }


        private void LocationBox_DropDownClosed(object sender, EventArgs e)
        {
            if(LocationBox.Text == "Menu")
            {
                ContentFrame.Navigate(new TrackingScreen());
                IAmAt = menu;
            }
            else if (LocationBox.Text == "Forest")
            {
                if(protag.inventory.Count == 0|| protag.inventory[0].ID >= 4)
                {
                    ContentFrame.Navigate(new Forest2());
                    IAmAt = forest2;
                }
                else
                {
                    ContentFrame.Navigate(new Forest1());
                    IAmAt = forest1;

                }

            }
            else if (LocationBox.Text == "Village")
            {
                ContentFrame.Navigate(new Village1());
                IAmAt = village1;

            }
            else if (LocationBox.Text == "Pharmacy")
            {
                ContentFrame.Navigate(new Pharmacy1());
                IAmAt = pharmacy1;


            }
            else if (LocationBox.Text == "Mountain")
            {
                ContentFrame.Navigate(new Mountain1());
                IAmAt = mountain1;


            }
            else if (LocationBox.Text == "Desert")
            {
                ContentFrame.Navigate(new Desert1());
                IAmAt = desert1;


            }
            else
            {
                ContentFrame.Navigate(new TrackingScreen());
                IAmAt = menu;

            }

        }

        public void AddWhiteChick()
        {
            if (protag.inventory[0].ID > 0)
            {
                ContentBox.Content = "This is not the chick you're looking for\nFor my next trick....\nDisapeeeeeeeaaaaaaar";
            }
            else
            {
                protag.inventory.RemoveAt(0);
                protag.inventory.Add(new Item("White Chick", 1));
                InventoryDisplay.Content = protag.inventory[0].name;
                Uri soundDing = new Uri("resources/SmallItemGetOoTN64.mp3", UriKind.Relative);
                effectPlayer.Open(soundDing);
                effectPlayer.Play();


            }
        }
        public void CheckTrade()
        {
            Uri soundDing = new Uri("resources/SmallItemGetOoTN64.mp3", UriKind.Relative);
            fullDialogue = "";
            bool canTrade = false;
            if (IAmAt.name == village1.name)
            {
                if (protag.inventory[0].ID < 2)
                {
                    canTrade = CuccooLady.ShowMe(protag.inventory);
                    if (canTrade)
                    {
                        fullDialogue += "A " + protag.inventory[0].name + "...for me..?\nThank you so much! Here's a " + CuccooLady.tradable.name;
                        protag.inventory.RemoveAt(0);
                        protag.inventory.Add(CuccooLady.tradable);
                        InventoryDisplay.Content = protag.inventory[0].name;
                        effectPlayer.Open(soundDing);
                        effectPlayer.Play();
                    }
                    else
                    {
                        fullDialogue += CuccooLady.distressStatement;
                        fullDialogue += "\nSorry... that's not the thing I was looking for";
                    }
                }
            }
            else if (protag.inventory.Any())
            {
                if (IAmAt.name == "Forest" && IAmAt.instance == 1)
                {
                    if (protag.inventory[0].ID < 3)
                    {
                        canTrade = ThisGuy.ShowMe(protag.inventory);
                        if (canTrade)
                        {
                            fullDialogue += "A " + protag.inventory[0].name + "...for me..?\nThank you so much! Here's a " + ThisGuy.tradable.name;
                            protag.inventory.RemoveAt(0);
                            protag.inventory.Add(ThisGuy.tradable);
                            InventoryDisplay.Content = protag.inventory[0].name;
                            effectPlayer.Open(soundDing);
                            effectPlayer.Play();
                        }
                        else
                        {
                            fullDialogue += ThisGuy.distressStatement;
                            fullDialogue += "\nSorry... that's not the thing I was looking for";
                        }
                    }
                }
                else if (IAmAt.name == "Forest" && IAmAt.instance == 2)
                {

                    if (protag.inventory[0].ID < 5)
                    {
                        canTrade = CreepyGirl.ShowMe(protag.inventory);
                        if (canTrade)
                        {
                            fullDialogue += "A " + protag.inventory[0].name + "...for me..?\nThank you so much! Here's a " + CreepyGirl.tradable.name;
                            protag.inventory.RemoveAt(0);
                            protag.inventory.Add(CreepyGirl.tradable);
                            InventoryDisplay.Content = protag.inventory[0].name;
                            effectPlayer.Open(soundDing);
                            effectPlayer.Play();
                        }
                        else
                        {
                            fullDialogue += CreepyGirl.distressStatement;
                            fullDialogue += "\nSorry... that's not the thing I was looking for";

                        }
                    }
                }
                
                else if (IAmAt.name == pharmacy1.name)
                {
                    if (protag.inventory[0].ID < 4)
                    {
                        canTrade = Granny1.ShowMe(protag.inventory);
                        if (canTrade)
                        {
                            fullDialogue += "A " + protag.inventory[0].name + "...for me..?\nThank you so much! Here's a " + Granny1.tradable.name;
                            protag.inventory.RemoveAt(0);
                            protag.inventory.Add(Granny1.tradable);
                            InventoryDisplay.Content = protag.inventory[0].name;
                            effectPlayer.Open(soundDing);
                            effectPlayer.Play();
                        }
                        else
                        {
                            fullDialogue += Granny1.distressStatement;
                            fullDialogue += "\nSorry... that's not the thing I was looking for";
                        }
                    }
                    else if (protag.inventory[0].ID > 4 && protag.inventory[0].ID <= 7)
                    {
                        canTrade = Granny2.ShowMe(protag.inventory);
                        if (canTrade)
                        {
                            fullDialogue += "A " + protag.inventory[0].name + "...for me..?\nThank you so much! Here's a " + Granny2.tradable.name;
                            protag.inventory.RemoveAt(0);
                            protag.inventory.Add(Granny2.tradable);
                            InventoryDisplay.Content = protag.inventory[0].name;
                            effectPlayer.Open(soundDing);
                            effectPlayer.Play();
                        }
                        else
                        {
                            fullDialogue += Granny2.distressStatement;
                            fullDialogue += "\nSorry... that's not the thing I was looking for";
                        }
                    }
                }
                else if (IAmAt.name == desert1.name)
                {
                    if (protag.inventory[0].ID <= 5)
                    {
                        canTrade = craftsman.ShowMe(protag.inventory);
                        if (canTrade)
                        {
                            fullDialogue += "A " + protag.inventory[0].name + "...for me..?\nThank you so much! Here's a " + craftsman.tradable.name;
                            protag.inventory.RemoveAt(0);
                            protag.inventory.Add(craftsman.tradable);
                            InventoryDisplay.Content = protag.inventory[0].name;
                            effectPlayer.Open(soundDing);
                            effectPlayer.Play();
                        }
                        else
                        {
                            fullDialogue += craftsman.distressStatement;
                            fullDialogue += "\nSorry... that's not the thing I was looking for";
                        }
                    }
                }
                else if (IAmAt.name == mountain1.name)
                {
                    if (protag.inventory[0].ID < 7)
                    {
                        canTrade = Biggoron1.ShowMe(protag.inventory);
                        if (canTrade)
                        {
                            fullDialogue += "A " + protag.inventory[0].name + "...for me..?\nThank you so much! Here's a " + Biggoron1.tradable.name;
                            protag.inventory.RemoveAt(0);
                            protag.inventory.Add(Biggoron1.tradable);
                            InventoryDisplay.Content = protag.inventory[0].name;
                            effectPlayer.Open(soundDing);
                            effectPlayer.Play();
                        }
                        else
                        {
                            fullDialogue += Biggoron1.distressStatement;
                            fullDialogue += "\nSorry... that's not the thing I was looking for";
                        }
                    }
                    else if (protag.inventory[0].ID >= 7)
                    {
                        canTrade = Biggoron2.ShowMe(protag.inventory);
                        if (canTrade)
                        {
                            fullDialogue += "A " + protag.inventory[0].name + "...for me..?\nThank you so much! Here's a " + Biggoron2.tradable.name;
                            protag.inventory.RemoveAt(0);
                            protag.inventory.Add(Biggoron2.tradable);
                            InventoryDisplay.Content = protag.inventory[0].name;
                            effectPlayer.Open(soundDing);
                            effectPlayer.Play();
                        }
                        else
                        {
                            fullDialogue += Biggoron2.distressStatement;
                            fullDialogue += "\nSorry... that's not the thing I was looking for";
                        }
                    }
                }
               
            }
            else
            {
                MessageBox.Show("It WOOOOOOORKS!!!");

            }
            ContentBox.Content = fullDialogue;
        }

        public int ReturnItemID()
        {
            return protag.inventory[0].ID;
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            pName = NameBox.Text;
            protag.name = pName;
        }
    }


}
