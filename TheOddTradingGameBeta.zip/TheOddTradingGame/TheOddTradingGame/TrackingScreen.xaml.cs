﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace TheOddTradingGame
{
    /// <summary>
    /// Interaction logic for TrackingScreen.xaml
    /// </summary>
    public partial class TrackingScreen : Page
    {
        public TrackingScreen()
        {
            InitializeComponent();
            if (((MainWindow)Application.Current.MainWindow).ReturnItemID() <= 0)
            {
                NumberNumberOfTrades.Content = 0;

            }
            else
            {
                NumberNumberOfTrades.Content = ((MainWindow)Application.Current.MainWindow).ReturnItemID() - 1;
            }
            if (((MainWindow)Application.Current.MainWindow).ReturnItemID() == 9)
            {
                YesNo.Content = "Yes";
            }
            else
            {
                YesNo.Content = "No";
            }
            DispatcherTimer timer = new DispatcherTimer();
            timer.Tick += new EventHandler(timerEvent);
            timer.Interval = new TimeSpan(0, 0, 1);
            timer.Start();

        }

        private void timerEvent(object sender, EventArgs e)
        {
            if (((MainWindow)Application.Current.MainWindow).protag.name == " " || ((MainWindow)Application.Current.MainWindow).protag.name == "" || ((MainWindow)Application.Current.MainWindow).protag.name == "Textbox")
            {

                Instructions.Text = "Welcome to The Odd Trading Game! Here, you are the Legendary Hero (type your name into the name box) who is on a quest to find the Stabby Stab. In order to do that, you must the other people find their lost objects. Now begone Yee, find the Sacred Stabby Stab";

            }
            else
            {
                Instructions.Text = $"Welcome to The Odd Trading Game! Here, you are the Legendary Hero {((MainWindow)Application.Current.MainWindow).protag.name} who is on a quest to find the Stabby Stab. In order to do that, you must the other people find their lost objects. Now begone Yee, find the Sacred Stabby Stab";

            }
        }


        
    }
}
