﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace TheOddTradingGame
{
    internal class Game
    {
        Player protag = new Player();

        NPC ThisGuy = new NPC("This Guy", "Oh no! My poor Smurf Chick... where have you run to...\nI'll give you something in return if you can\nfind him and bring him back!", new Item("Dope Shroom", 3), new Uri("Resources/ThisGuy.png", UriKind.Relative));
        NPC CreepyGirl = new NPC("Creepy Girl", "Man, I am starving. Oh, the old guy? \nHe's Dead. I'll give you something in return if you can\ngive me something to eat.", new Item("Jiggy Saw", 5), new Uri("Resources/CreepyGirl.png", UriKind.Relative));
        NPC craftsman = new NPC("Craftsman", "I would love to start working, but I seem to missing my saw.\nDo you have it?", new Item("Broken Sword", 6), new Uri("Resources/Craftsman.png", UriKind.Relative));
        NPC Biggoron1 = new NPC("Biggoron", "Im the world's best swordsmith. I'd love to fix something, but I need something to fix first", new Item("Prescription", 7), new Uri("Resources / Biggoron.png", UriKind.Relative));
        NPC Biggoron2 = new NPC("Biggoron", "I need my eyedrops to fix anything.\nSo, did you bring my eyedrops back yet?", new Item("Stabby Stab", 9), new Uri("Resources/Biggoron.png", UriKind.Relative));
        NPC Granny1 = new NPC("Granny", "If only I had something to make a potion with... Then I'd be happy\nIf you give me that item, I might be able to cook something for you", new Item("Odd Potluck", 4), new Uri("Resources/Granny.png", UriKind.Relative));
        NPC Granny2 = new NPC("Granny", "I have a patient that's coming soon\nI'll just need his prescription and I'll be all set to hand this off", new Item("World's Biggest Eyedrops", 8), new Uri("Resources/Granny.png", UriKind.Relative));
        NPC CuccooLady = new NPC("Cuccoo Lady", "Oh no! I've lost my White Chick... \nI'll give you something in return if you can\nfind him and bring him back!", new Item("Smurf Chick", 2), new Uri("Resources/CuccoLady.png", UriKind.Relative));

    }

    


}
