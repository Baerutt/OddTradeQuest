﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheOddTradingGame
{
    internal class NPC
    {
        public string name;
        public string distressStatement;
        public Item tradable;
        public Uri selfImage;

        public NPC()
        {

        }

        public NPC(string myName, string myDistressStatement, Item myItem, Uri myImage)
        {
            name = myName;
            distressStatement = myDistressStatement;
            tradable = myItem;
            selfImage = myImage;
        }

        public bool ShowMe(List<Item> stuff)
        {

            bool canTrade = false;
            for (int i = 0; i < stuff.Count; i++)
            {
                if (stuff[i].ID == tradable.ID - 1)
                {
                    canTrade = true;
                }
            }
            return canTrade;
        }
        public string Trade(Player protag)
        {
 
             return "A " + protag.inventory[0].name + "...for me..?\nThank you so much! Here's a " + tradable.name;
            
                 
            

        }

        public string NoTrade()
        {
            return "Sorry... that's not the thing I was looking for";
        }

    }
}
