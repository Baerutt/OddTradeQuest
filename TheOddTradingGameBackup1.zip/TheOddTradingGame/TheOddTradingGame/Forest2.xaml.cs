﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TheOddTradingGame
{
    /// <summary>
    /// Interaction logic for Forest2.xaml
    /// </summary>
    public partial class Forest2 : Page
    {
        public Forest2()
        {
            InitializeComponent();
        }

        private void NPCCreepyGirl_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).CheckTrade();
        }
    }
}
