﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheOddTradingGame
{
    internal class Location
    {
        public string name { get; set; }

        public int instance { get; set; }

        public Location()
        {

        }

        public Location(string myName, int myInstance)
        {
            name = myName;
            instance = myInstance;
        }




    }
}
